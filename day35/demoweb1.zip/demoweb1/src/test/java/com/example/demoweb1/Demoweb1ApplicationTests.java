package com.example.demoweb1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoweb1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
