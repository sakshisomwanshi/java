package com.example.demoOneToMany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOneToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
